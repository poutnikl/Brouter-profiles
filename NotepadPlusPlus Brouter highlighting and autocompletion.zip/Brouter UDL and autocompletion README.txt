BRouter syntax highlighting, folding and autocompletion files for Notepad++

Usage:

1) Go to "Language"->"Define your language..."
2) Click "Import..." in window
3) Pick "brouter-fold.xml" from this archive
4) Restart the Notepad++

To use function autocompletion feature
place "BRouter.xml"
into <Notepad++ program folder>\plugins\APIs folder
( Elevated admin rights may be needed )

Read Notepad++ documentation for
details.

Author: Libor Striz
poutnikq@atlas.cz
